import json
import requests
import pandas as pd
import numpy as np
import colorama
from colorama import Fore, Back, Style

colorama.init(autoreset=True)
print("Welcome to the " + Fore.BLUE + "Blue Jays" + Style.RESET_ALL + " schedule!")
print(Style.RESET_ALL)

ended = 0
while ended == 0:
    selectYear = 0
    while selectYear == 0:
        print()
        ansYear = input("Enter Year (2000-2021): ")
        print()
        try:
            if int(ansYear) >= 2000 and int(ansYear) <= 2021:
                selectYear = 1
            else:
                print()
                print('Please enter a correct year')
                print()
        except:
                print()
                print('Please enter a correct year')
                print()


    selectMonth = 0
    while selectMonth == 0:
        with open('months.json') as f:
            js = json.load(f)
            try:
                print()
                ans = input("Enter Month: ")
                print()
                month = js[ans.lower()]['number']
                if len(str(month)) == 1:
                    newmonth = '0' + str(month)
                    selectMonth = 1
                else:
                    newmonth = month
                    selectMonth = 0
            except:
                print()
                print('Please enter a correct month')
                print()


    url = "https://statsapi.mlb.com/api/v1/schedule?lang=en&sportId=1&hydrate=team(venue(timezone)),venue(timezone),game(seriesStatus,seriesSummary,tickets,promotions,sponsorships,content(summary,media(epg))),seriesStatus,seriesSummary,linescore,tickets,event(tickets),radioBroadcasts,broadcasts(all)&season=" + ansYear + "&startDate=" + ansYear + "-" + newmonth + "-01&endDate=" + ansYear + "-" + newmonth + "-30&teamId=141&eventTypes=primary&scheduleTypes=games,events,xref"


    headers = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
      'Accept': 'application/json, text/javascript, */*; q=0.01',
      'Accept-Language': 'en-CA,en-US;q=0.7,en;q=0.3',
      'Origin': 'https://www.mlb.com',
      'Connection': 'keep-alive',
      'Referer': 'https://www.mlb.com/',
      'Cache-Control': 'max-age=0',
      'TE': 'Trailers'
    }

    r = requests.get(url, headers=headers)

    gameData = r.json()

    theBreak = ' | '
    secondBreak = '  | '

    def TeamRecord(gameNum, homeAway):
        return str(gameData['dates'][gameNum]['games'][0]['teams'][homeAway]['leagueRecord']['wins']) + '-' + str(gameData['dates'][gameNum]['games'][0]['teams'][homeAway]['leagueRecord']['losses'])

    def date(gameNum):
        dt = gameData['dates'][gameNum]['date']
        mt = dt[8:10]
        if mt[0] == '0':
            lastDate = mt[1:]
        else:
            lastDate = mt
        lastDateInt = int(lastDate)
        if lastDateInt <= 9:
            lastDate = lastDate + ' '
        return lastDate

    def AwayTeam(gameNum):
        return gameData['dates'][gameNum]['games'][0]['teams']['away']['team']['abbreviation']

    def HomeTeam(gameNum):
        return gameData['dates'][gameNum]['games'][0]['teams']['home']['team']['abbreviation']

    def ScoreResult(gameNum):
        try:
            resultHome = gameData['dates'][gameNum]['games'][0]['teams']['home']['score']
            resultAway = gameData['dates'][gameNum]['games'][0]['teams']['away']['score']
            if HomeTeam(gameNum) == 'Toronto Blue Jays':
                resultTOR = resultHome
                resultOPP = resultAway
            else:
                resultTOR = resultAway
                resultOPP = resultHome
            if resultTOR > resultOPP:
                worl = "W"
            else:
                worl = "L"
            if worl == "W":
                if resultHome >= 10 or resultAway >= 10:
                    return str(resultTOR) + '-' + str(resultOPP) + ' W' + ' | '
                else:
                    return str(resultTOR) + '-' + str(resultOPP) + ' W' + '  | '
            else:
                if resultHome >= 10 or resultAway >= 10:
                    return str(resultOPP) + '-' + str(resultTOR) + ' L' + ' | '
                else:
                    return str(resultOPP) + '-' + str(resultTOR) + ' L' + '  | '

        except:
            plannedTimeMil = gameData['dates'][gameNum]['games'][0]['gameDate']
            hoursStr = plannedTimeMil[11:13]
            minutesStr = plannedTimeMil[14:16]
            hoursB = int(hoursStr)
            if hoursB > 12:
                setting = "PM"
                hoursB -= 12
            else:
                setting = "AM"
            if hoursB > 7:
                hours = hoursB - 7
            elif hoursB >= 1 and hoursB <= 6:
                if setting == "PM":
                    setting = "AM"
                    hours = hoursB + 5
                elif setting == "AM":
                    setting == "PM"
                    hours = hoursB + 5
            elif hoursB == 7:
                    hours = 12
            elif hoursB == 12:
                if setting == "PM":
                    setting = "AM"
                    hours = 5
                elif setting == "AM":
                    setting == "PM"
                    hours = 5

            return str(hours) + ':' + minutesStr + setting + ' ' 'PT' +  '  | '

    def HomeOrAway(gameNum):
        homeTeam = gameData['dates'][gameNum]['games'][0]['teams']['home']['team']['abbreviation']
        if homeTeam == 'TOR':
            return 'home'
        else:
            return 'away'

    amountOfGames = len(gameData['dates'])

    gameNumber = 0
    while amountOfGames > gameNumber:
        if "W" in ScoreResult(gameNumber):
            print(ans.capitalize() + ' ' + date(gameNumber) + theBreak + AwayTeam(gameNumber) + ' @ ' + HomeTeam(gameNumber) + '  ' + Fore.GREEN + ScoreResult(gameNumber) + Style.RESET_ALL + TeamRecord(gameNumber, HomeOrAway(gameNumber)))
        elif "L" in ScoreResult(gameNumber):
            print(ans.capitalize() + ' ' + date(gameNumber) + theBreak + AwayTeam(gameNumber) + ' @ ' + HomeTeam(gameNumber) + '  ' + Fore.RED + ScoreResult(gameNumber) + Style.RESET_ALL + TeamRecord(gameNumber, HomeOrAway(gameNumber)))
        elif "PT" in ScoreResult(gameNumber):
            print(ans.capitalize() + ' ' + date(gameNumber) + theBreak + AwayTeam(gameNumber) + ' @ ' + HomeTeam(gameNumber) + '  ' + Fore.BLUE + ScoreResult(gameNumber) + Style.RESET_ALL + TeamRecord(gameNumber, HomeOrAway(gameNumber)))
        gameNumber += 1
